#include <stdio.h>
#include <stdlib.h>

struct Node {
    int data;
    struct Node* prev;
    struct Node* next;
};

struct Node* insertBegin(struct Node* head, int value) {

    struct Node* newNode = (struct Node*)malloc(sizeof(struct Node));
    newNode->data = value;

    newNode->prev = NULL;     
    newNode->next = head;      

    if (head != NULL) {
        head->prev = newNode;  
    }

    head = newNode;            
    return head;
}


struct Node* insertEnd(struct Node* head, int value) {

    struct Node* newNode = (struct Node*)malloc(sizeof(struct Node));
    newNode->data = value;
    newNode->next = NULL;

  
    if (head == NULL) {
        newNode->prev = NULL;
        return newNode;
    }

    struct Node* temp = head;

    
    while (temp->next != NULL) {
        temp = temp->next;
    }

    temp->next = newNode;   
    newNode->prev = temp;   

    return head;
}


void displayForward(struct Node* head) {

    struct Node* temp = head;

    while (temp != NULL) {
        printf("%d <-> ", temp->data);
        temp = temp->next;
    }
    printf("NULL\n");
}


void displayBackward(struct Node* head) {

    struct Node* temp = head;


    while (temp->next != NULL) {
        temp = temp->next;
    }

    while (temp != NULL) {
        printf("%d <-> ", temp->data);
        temp = temp->prev;
    }
    printf("NULL\n");
}


int main() {

    struct Node* head = NULL;

    head = insertBegin(head, 10);
    head = insertBegin(head, 5);
    head = insertEnd(head, 20);
    head = insertEnd(head, 30);

    printf("Forward: ");
    displayForward(head);

    printf("Backward: ");
    displayBackward(head);

    return 0;
}